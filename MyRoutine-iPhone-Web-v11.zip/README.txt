My Routine V11 — Weight import
Run the shortcut, open Weight, paste JSON into Apple Health Sync and tap Import weigh-in. Hosting and iPhone testing are pending.
